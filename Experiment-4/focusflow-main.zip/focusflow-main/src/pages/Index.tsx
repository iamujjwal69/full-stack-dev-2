import { Link } from "react-router-dom";
import { CheckSquare, BarChart2, Sun, ArrowRight, ListTodo } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useTaskContext } from "@/context/TaskContext";

const features = [
  {
    icon: ListTodo,
    title: "Task Management",
    description: "Add, complete, and delete tasks with a clean card-based interface.",
  },
  {
    icon: CheckSquare,
    title: "Smart Filtering",
    description: "Filter tasks by All, Pending, or Completed to stay focused.",
  },
  {
    icon: BarChart2,
    title: "Analytics Dashboard",
    description: "Track your productivity score and completion rate at a glance.",
  },
  {
    icon: Sun,
    title: "Light & Dark Mode",
    description: "Switch themes instantly — your eyes will thank you.",
  },
];

export default function Index() {
  const { state } = useTaskContext();
  const total = state.tasks.length;
  const completed = state.tasks.filter((t) => t.completed).length;
  const pending = total - completed;

  return (
    <main className="container mx-auto max-w-5xl px-4 py-12">
      {/* Hero */}
      <section className="mb-16 text-center">
        <div className="mb-4 inline-flex items-center rounded-full bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
          ⚡ Smart Productivity Dashboard
        </div>
        <h1 className="mb-4 text-5xl font-extrabold tracking-tight text-foreground sm:text-6xl">
          Focus on what
          <span className="text-primary"> matters most</span>
        </h1>
        <p className="mx-auto mb-8 max-w-xl text-lg text-muted-foreground">
          FocusFlow helps you manage daily tasks, track your progress, and boost productivity — all in one clean, minimal dashboard.
        </p>
        <div className="flex flex-wrap justify-center gap-4">
          <Button asChild size="lg" className="gap-2">
            <Link to="/tasks">
              Go to Tasks <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
          <Button asChild size="lg" variant="outline" className="gap-2">
            <Link to="/analytics">
              View Analytics <BarChart2 className="h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>

      {/* Quick Summary */}
      <section className="mb-16">
        <h2 className="mb-6 text-center text-2xl font-bold text-foreground">Quick Summary</h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <Card className="text-center transition-shadow hover:shadow-md">
            <CardContent className="pt-6">
              <p className="text-4xl font-extrabold text-foreground">{total}</p>
              <p className="mt-1 text-sm font-medium text-muted-foreground">Total Tasks</p>
            </CardContent>
          </Card>
          <Card className="text-center transition-shadow hover:shadow-md">
            <CardContent className="pt-6">
              <p className="text-4xl font-extrabold text-primary">{completed}</p>
              <p className="mt-1 text-sm font-medium text-muted-foreground">Completed</p>
            </CardContent>
          </Card>
          <Card className="text-center transition-shadow hover:shadow-md">
            <CardContent className="pt-6">
              <p className="text-4xl font-extrabold text-foreground">{pending}</p>
              <p className="mt-1 text-sm font-medium text-muted-foreground">Pending</p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Feature Highlights */}
      <section>
        <h2 className="mb-6 text-center text-2xl font-bold text-foreground">What's inside</h2>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {features.map(({ icon: Icon, title, description }) => (
            <Card key={title} className="transition-shadow hover:shadow-md">
              <CardContent className="flex items-start gap-4 pt-6">
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="mb-1 font-semibold text-foreground">{title}</h3>
                  <p className="text-sm text-muted-foreground">{description}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </main>
  );
}
