import { useState } from "react";
import { Trash2, Plus, ClipboardList } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { useTaskContext } from "@/context/TaskContext";

type FilterTab = "all" | "pending" | "completed";

export default function Tasks() {
  const { state, dispatch } = useTaskContext();
  const [inputValue, setInputValue] = useState("");
  const [filter, setFilter] = useState<FilterTab>("all");

  const handleAddTask = () => {
    const trimmed = inputValue.trim();
    if (!trimmed) return;
    dispatch({ type: "ADD_TASK", payload: trimmed });
    setInputValue("");
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") handleAddTask();
  };

  const hasCompleted = state.tasks.some((t) => t.completed);

  const filteredTasks = state.tasks.filter((task) => {
    if (filter === "pending") return !task.completed;
    if (filter === "completed") return task.completed;
    return true;
  });

  return (
    <main className="container mx-auto max-w-2xl px-4 py-12">
      <h1 className="mb-2 text-3xl font-extrabold tracking-tight text-foreground">My Tasks</h1>
      <p className="mb-8 text-muted-foreground">Add tasks, track progress, and stay on top of your day.</p>

      {/* Add Task */}
      <div className="mb-8 flex gap-2">
        <Input
          placeholder="What do you need to do?"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onKeyDown={handleKeyDown}
          className="flex-1"
        />
        <Button onClick={handleAddTask} className="gap-2 shrink-0">
          <Plus className="h-4 w-4" />
          Add Task
        </Button>
      </div>

      {/* Filter Tabs */}
      <Tabs value={filter} onValueChange={(v) => setFilter(v as FilterTab)}>
        <div className="mb-4 flex items-center justify-between">
          <TabsList>
            <TabsTrigger value="all">All ({state.tasks.length})</TabsTrigger>
            <TabsTrigger value="pending">Pending ({state.tasks.filter((t) => !t.completed).length})</TabsTrigger>
            <TabsTrigger value="completed">Completed ({state.tasks.filter((t) => t.completed).length})</TabsTrigger>
          </TabsList>

          {hasCompleted && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => dispatch({ type: "CLEAR_COMPLETED" })}
              className="text-destructive hover:bg-destructive/10 hover:text-destructive border-destructive/30"
            >
              Clear Completed
            </Button>
          )}
        </div>

        {(["all", "pending", "completed"] as FilterTab[]).map((tab) => (
          <TabsContent key={tab} value={tab} className="space-y-3">
            {filteredTasks.length === 0 ? (
              <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border py-16 text-center">
                <ClipboardList className="mb-3 h-10 w-10 text-muted-foreground/50" />
                <p className="text-base font-medium text-muted-foreground">
                  {tab === "all"
                    ? "No tasks yet. Add one above!"
                    : tab === "pending"
                    ? "No pending tasks — nice work! 🎉"
                    : "No completed tasks yet."}
                </p>
              </div>
            ) : (
              filteredTasks.map((task) => (
                <Card
                  key={task.id}
                  className="group transition-shadow hover:shadow-md"
                >
                  <CardContent className="flex items-center gap-3 py-4 px-5">
                    <Checkbox
                      checked={task.completed}
                      onCheckedChange={() => dispatch({ type: "TOGGLE_TASK", payload: task.id })}
                      className="shrink-0"
                    />
                    <span
                      className={`flex-1 text-sm font-medium transition-colors ${
                        task.completed
                          ? "text-muted-foreground line-through"
                          : "text-foreground"
                      }`}
                    >
                      {task.title}
                    </span>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => dispatch({ type: "DELETE_TASK", payload: task.id })}
                      className="h-8 w-8 shrink-0 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100 hover:text-destructive"
                      aria-label="Delete task"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>
        ))}
      </Tabs>
    </main>
  );
}
