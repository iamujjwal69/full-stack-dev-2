import { useMemo } from "react";
import { TrendingUp, CheckCircle, Clock, Target } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useTaskContext } from "@/context/TaskContext";

interface StatCard {
  label: string;
  value: string | number;
  icon: React.ElementType;
  description?: string;
}

function getProductivityScore(percentage: number): {
  label: string;
  message: string;
  color: string;
} {
  if (percentage >= 80) return { label: "Excellent 🏆", message: "You're crushing it! Keep up the amazing momentum.", color: "text-primary" };
  if (percentage >= 60) return { label: "Good 👍", message: "Solid progress! A few more tasks and you'll be unstoppable.", color: "text-primary" };
  if (percentage >= 40) return { label: "Fair ⚡", message: "You're on your way. Focus on completing a few more tasks today.", color: "text-muted-foreground" };
  return { label: "Needs Work 💪", message: "Every journey starts with a single step. Start completing tasks now!", color: "text-muted-foreground" };
}

export default function Analytics() {
  const { state } = useTaskContext();

  // ── All calculations memoized, only recompute when tasks change ──────────────
  const totalTasks = useMemo(() => state.tasks.length, [state.tasks]);

  const completedTasks = useMemo(
    () => state.tasks.filter((t) => t.completed).length,
    [state.tasks]
  );

  const pendingTasks = useMemo(() => totalTasks - completedTasks, [totalTasks, completedTasks]);

  const completionPercentage = useMemo(
    () => (totalTasks === 0 ? 0 : Math.round((completedTasks / totalTasks) * 100)),
    [completedTasks, totalTasks]
  );

  const productivityScore = useMemo(
    () => getProductivityScore(completionPercentage),
    [completionPercentage]
  );

  const statCards: StatCard[] = useMemo(
    () => [
      { label: "Total Tasks", value: totalTasks, icon: Target, description: "Tasks created so far" },
      { label: "Completed", value: completedTasks, icon: CheckCircle, description: "Tasks marked as done" },
      { label: "Pending", value: pendingTasks, icon: Clock, description: "Tasks still in progress" },
      { label: "Completion Rate", value: `${completionPercentage}%`, icon: TrendingUp, description: "Overall completion" },
    ],
    [totalTasks, completedTasks, pendingTasks, completionPercentage]
  );

  return (
    <main className="container mx-auto max-w-5xl px-4 py-12">
      <h1 className="mb-2 text-3xl font-extrabold tracking-tight text-foreground">Analytics</h1>
      <p className="mb-8 text-muted-foreground">
        Your productivity at a glance — powered by <code className="rounded bg-muted px-1 py-0.5 text-xs font-mono text-foreground">useMemo</code>.
      </p>

      {/* Stat Cards */}
      <section className="mb-10 grid grid-cols-2 gap-4 sm:grid-cols-4">
        {statCards.map(({ label, value, icon: Icon, description }) => (
          <Card key={label} className="transition-shadow hover:shadow-md">
            <CardHeader className="pb-2 pt-5">
              <div className="flex items-center justify-between">
                <p className="text-xs font-medium uppercase tracking-widest text-muted-foreground">{label}</p>
                <Icon className="h-4 w-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent className="pb-5">
              <p className="text-3xl font-extrabold text-foreground">{value}</p>
              {description && <p className="mt-1 text-xs text-muted-foreground">{description}</p>}
            </CardContent>
          </Card>
        ))}
      </section>

      {/* Progress Bar */}
      <section className="mb-10">
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-semibold text-foreground">Overall Progress</CardTitle>
          </CardHeader>
          <CardContent className="pb-6">
            <div className="mb-2 flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Completion</span>
              <span className="font-bold text-foreground">{completionPercentage}%</span>
            </div>
            <Progress value={completionPercentage} className="h-3" />
            <div className="mt-3 flex justify-between text-xs text-muted-foreground">
              <span>{completedTasks} completed</span>
              <span>{pendingTasks} remaining</span>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Productivity Score */}
      <section>
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-semibold text-foreground">Productivity Score</CardTitle>
          </CardHeader>
          <CardContent className="pb-6">
            {totalTasks === 0 ? (
              <p className="text-sm text-muted-foreground">
                No tasks yet. Head to the Tasks page and start adding some!
              </p>
            ) : (
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-6">
                <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-full bg-primary/10 text-3xl font-extrabold text-primary">
                  {completionPercentage}
                </div>
                <div>
                  <p className={`text-xl font-bold ${productivityScore.color}`}>
                    {productivityScore.label}
                  </p>
                  <p className="mt-1 text-sm text-muted-foreground">{productivityScore.message}</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </section>
    </main>
  );
}
