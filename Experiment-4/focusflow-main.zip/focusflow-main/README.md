🚀 FocusFlow

FocusFlow is a modern productivity and task management web application built with React + TypeScript + Vite.
It helps users manage tasks efficiently, track progress, and analyze productivity through a clean and responsive UI.

📌 Features

✅ Create, manage, and organize tasks

📊 Analytics dashboard for productivity insights

🔄 Global state management using React Context

🎨 Modern UI with Tailwind CSS and reusable UI components

⚡ Fast development with Vite

🧪 Testing setup with Vitest

🛠️ Tech Stack

Frontend: React + TypeScript

Build Tool: Vite

Styling: Tailwind CSS

UI Components: Custom reusable UI components

State Management: React Context API

Testing: Vitest


📊 Pages Overview
🏠 Home (Index)

Overview of application

Quick navigation

📋 Tasks

Add, edit, delete tasks

Manage task status

📈 Analytics

View productivity insights

Track completed tasks

🎯 Future Improvements

🔐 Authentication system

☁️ Backend integration

📅 Due dates & reminders

📱 Mobile app version